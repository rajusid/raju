#include <stdio.h>

int main() {
    // Write C code here
    int count = 1;
    while (count <= 10) {
       
            
           printf("3*%d=%d", count,3*count); 
           printf("\n");
        
        count++;
    }

    return 0;
}
