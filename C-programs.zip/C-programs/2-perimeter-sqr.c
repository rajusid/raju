#include<stdio.h>

int main()
{
	int l, perimeter;

	printf("enter the length of side: ");
	scanf("%d", &l);

	perimeter = 4*l;
	printf("perimeter of sqr: %d\n", perimeter);
	return 0;
}
