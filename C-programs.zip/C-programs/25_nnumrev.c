#include <stdio.h>

int main() {
    // Write C code here
    int num,n;
    printf("enter the range");
    scanf("%d", &n);
    num=n;
    while (num>0) {
        
           printf("%d ", num); 
       
        num--;
    }

    return 0;
}
