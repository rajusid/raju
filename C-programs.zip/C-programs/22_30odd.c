#include <stdio.h>

int main() {
    // Write C code here
    int num=1;
    //here printing first 10 even numbers
    while(num<=59){
       printf("%d,",num); 
       num+=2;
    }

    return 0;
}
