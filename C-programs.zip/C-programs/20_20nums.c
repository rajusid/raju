#include <stdio.h>

int main() {
    // Write C code here
    int num=1;
    
    while(num<=20){
       printf("%d,",num); 
       num++;
    }

    return 0;
}
