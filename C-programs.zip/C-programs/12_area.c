#include <stdio.h>

int main() {
    float l,b;
    float area;

    printf("enter the length and breadth");
    scanf("%f%f",&l,&b);
    area = l*b;
    printf("area of rectangle is%f",area);

    return 0;
}
