#include <stdio.h>

int main() {
    // Write C code here
    int num = 40;

    while (num > 0) {
        printf("%d ", num);
        num -= 2;
    }

    return 0;
}

