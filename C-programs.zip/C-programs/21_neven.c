#include <stdio.h>

int main() {
    // Write C code here
    int num=2;
    //here printing first 10 even numbers
    while(num<=20){
       printf("%d,",num); 
       num+=2;
    }

    return 0;
}
